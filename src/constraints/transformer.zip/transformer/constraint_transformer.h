#pragma once

#include "constraint_build_report.h"
#include "constraint_map.h"
#include "constraint_system.h"
#include "null_space.h"

#include <limits>

namespace fem {
namespace constraint {

class ConstraintTransformer {
public:
    enum class Method {
        NullSpace,
        Lagrange,
        Elimination
    };

    struct Options {
        Method             method{};
        ConstraintOptions  constraints{};
        NullSpaceOptions   null_space{};
        Precision          lagrange_regularization = Precision(1e-10);
    };

    ConstraintTransformer(const Equations& equations,
                          const SystemDofIds& dofs,
                          Index n_dofs);

    ConstraintTransformer(const Equations& equations,
                          const SystemDofIds& dofs,
                          Index n_dofs,
                          const Options& options);

    Method      method() const { return method_; }
    const char* method_name() const;

    const ConstraintSystem&      system() const { return system_; }
    const ConstraintBuildReport& report() const { return report_; }
    const ConstraintMap&         reduced_map() const;

    bool has_reduced_map() const { return method_ != Method::Lagrange; }
    bool homogeneous() const { return report_.homogeneous; }
    bool feasible() const { return report_.feasible; }
    bool rank_known() const { return report_.rank_known; }

    Index rank() const { return report_.rank; }
    Index unknowns() const;
    Index independent_dofs() const;

    SparseMatrix  assemble_system_matrix(const SparseMatrix& K) const;
    SparseMatrix  reduce_secondary_matrix(const SparseMatrix& matrix) const;
    DynamicVector assemble_system_rhs(const SparseMatrix& K, const DynamicVector& f) const;

    void          project_vector(const DynamicVector& full, DynamicVector& reduced) const;
    DynamicVector project_vector(const DynamicVector& full) const;
    DynamicVector recover_displacement(const DynamicVector& solution) const;
    DynamicVector recover_increment(const DynamicVector& increment) const;
    DynamicVector recover_velocity(const DynamicVector& velocity) const;
    DynamicVector recover_acceleration(const DynamicVector& acceleration) const;

    DynamicVector reactions(const SparseMatrix& K,
                            const DynamicVector& f,
                            const DynamicVector& solution) const;

    DynamicVector support_reactions(const SparseMatrix& K,
                                    const DynamicVector& f,
                                    const DynamicVector& solution) const;

    void post_check_static(const SparseMatrix& K,
                           const DynamicVector& f,
                           const DynamicVector& solution,
                           Precision tol_constraint_rel = Precision(1e-10),
                           Precision tol_reduced_rel    = Precision(1e-8),
                           Precision tol_full_rel       = std::numeric_limits<Precision>::infinity()) const;

private:
    void initialize_lagrange();

    SparseMatrix  assemble_lagrange_matrix(const SparseMatrix& K) const;
    DynamicVector assemble_lagrange_rhs(const DynamicVector& f) const;
    DynamicVector extract_lagrange_displacement(const DynamicVector& solution) const;
    DynamicVector extract_lagrange_multipliers(const DynamicVector& solution) const;
    DynamicVector solve_multipliers(const SparseMatrix& K,
                                    const DynamicVector& f,
                                    const DynamicVector& u) const;
    DynamicVector support_constraint_forces(const DynamicVector& multipliers,
                                            bool scaled_rows) const;
    DynamicVector scale_lagrange_rows(const DynamicVector& values) const;
    Precision     lagrange_regularization(const SparseMatrix& K) const;

    Method                method_{};
    Precision             lagrange_regularization_{};
    DynamicVector         lagrange_row_scale_{};
    ConstraintSystem      system_{};
    ConstraintMap         map_{};
    ConstraintBuildReport report_{};
};

} // namespace constraint
} // namespace fem
