#pragma once

#include "constraint_build_report.h"
#include "constraint_map.h"
#include "constraint_system.h"

#include <utility>

namespace fem {
namespace constraint {

std::pair<ConstraintMap, ConstraintBuildReport> build_elimination(const ConstraintSystem& system);

} // namespace constraint
} // namespace fem
