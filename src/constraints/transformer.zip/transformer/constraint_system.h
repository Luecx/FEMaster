#pragma once

#include "../../core/types_cls.h"
#include "../../core/types_eig.h"
#include "../types/equation.h"

#include <vector>

namespace fem {
namespace constraint {

struct ConstraintOptions {
    Precision zero_row_drop_tolerance = Precision(0);
};

struct ConstraintSystem {
    Index equations{};
    Index dofs{};

    SparseMatrix  C{};
    DynamicVector d{};

    std::vector<EquationSourceKind> row_sources{};
};

ConstraintSystem assemble_constraint_system(const Equations&          equations,
                                            const SystemDofIds&       dofs,
                                            Index                     n_dofs,
                                            const ConstraintOptions& options = {});

} // namespace constraint
} // namespace fem
