#pragma once

#include "constraint_build_report.h"
#include "constraint_map.h"
#include "constraint_system.h"

#include <utility>

namespace fem {
namespace constraint {

struct NullSpaceOptions {
    Precision rank_tolerance        = Precision(1e-12);
    Precision feasibility_tolerance = Precision(1e-10);
};

std::pair<ConstraintMap, ConstraintBuildReport>
build_null_space(const ConstraintSystem& system, const NullSpaceOptions& options = {});

} // namespace constraint
} // namespace fem
