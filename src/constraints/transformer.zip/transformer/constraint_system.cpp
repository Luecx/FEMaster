#include "constraint_system.h"

#include "../../core/logging.h"

namespace fem {
namespace constraint {

ConstraintSystem assemble_constraint_system(const Equations&          equations,
                                            const SystemDofIds&       dofs,
                                            Index                     n_dofs,
                                            const ConstraintOptions& options) {
    ConstraintSystem system{};
    system.dofs = n_dofs;

    TripletList trips{};
    trips.reserve(64 * equations.size());

    system.row_sources.reserve(equations.size());

    std::vector<Precision> rhs_values{};
    rhs_values.reserve(equations.size());

    Index row = 0;
    for (const auto& equation : equations) {
        bool has_entry = false;

        for (const auto& term : equation.entries) {
            const int dof_id = dofs(term.node_id, term.dof);
            if (dof_id < 0) {
                continue;
            }

            has_entry = true;
            trips.emplace_back(row, dof_id, term.coeff);
        }

        if (has_entry || options.zero_row_drop_tolerance <= Precision(0)) {
            system.row_sources.push_back(equation.source);
            rhs_values.push_back(equation.rhs);
            ++row;
        }
    }

    system.equations = row;
    system.C.resize(system.equations, system.dofs);
    system.C.setFromTriplets(trips.begin(), trips.end());
    system.d.resize(static_cast<Eigen::Index>(rhs_values.size()));
    for (Index equation = 0; equation < system.equations; ++equation) {
        system.d[equation] = rhs_values[static_cast<std::size_t>(equation)];
    }

    logging::info(true,
                  "[ConstraintSystem] Assembled C: m=", system.equations,
                  " n=", system.dofs,
                  " nnz=", static_cast<Index>(system.C.nonZeros()));

    return system;
}

} // namespace constraint
} // namespace fem
